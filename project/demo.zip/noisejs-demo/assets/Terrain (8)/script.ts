// To make things easier
namespace Game {
  
  export let blocks:  Sup.Actor[] = []; // To easily access blocks with raycast
  export let diamond: Sup.Actor = null; // To easily tell which block is a diamond
  
}

// Terrain making behavior
class TerrainBehavior extends Sup.Behavior {
  
  width     = 7; // Width of terrain
  length    = 7; // Length of terrain
  maxHeight = 6; // Maximum height
  
  awake() {
    
    let stones: Sup.Actor[] = [];    // Possible locations for the diamond
    Noise.makeRandomSeed(); // Make a random seed for the terrain
    
    for ( let x = 0; x < this.width; x ++ ) {
      for ( let y = 0; y < this.length; y ++ ) {
        
        let height = ( Noise.simplex2d( x / 10, y / 10 ) + 1 ) / 2; // Get simplex2D height
        height = Math.floor( height * this.maxHeight ) + 1;                  // Make it friendlier for block placement
        
        for ( let z = 0; z < height; z ++ ) {
          
          let t = Sup.appendScene( "Blocks/Prefab" )[ 0 ];
          t.setPosition( -this.width / 2 + x, -this.maxHeight / 2 + z, -this.length / 2 + y );
          
          if      ( z === height - 2 ) { t.modelRenderer.setModel(  "Blocks/Dirt" ); }
          else if ( z   < height - 2 ) { 
            
            t.modelRenderer.setModel( "Blocks/Stone" );
            stones.push( t );
          
          }
          
          Game.blocks.push( t );
          
        }
        
      }
    }
    
    // Choose a stone block to be a diamond
    if ( stones.length > 1 ) {
      
      Game.diamond = stones[ Sup.Math.Random.integer( 0, stones.length - 1 ) ]
      Game.diamond.modelRenderer.setModel( "Blocks/Diamond" ); // Tell no one
          
    }
    
    Game.blocks.push( Sup.getActor( "Skybox" ) ); // To make sure the ray hits something
    
  }

  // no need to update

}
Sup.registerBehavior(TerrainBehavior);
