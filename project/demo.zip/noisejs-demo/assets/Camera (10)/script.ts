// Camera/main game behavior
class CameraBehavior extends Sup.Behavior {
  
  radius = 14; // distance from terrain center to camera
  
  private ray                  = new Sup.Math.Ray();
  private angle                = 0;
  private selection: Sup.Actor = null;

  update() {
    
    if ( Sup.Input.wasKeyJustPressed( "R" ) ) { Sup.loadScene( "Scene" ); }
    
    this.angle -= Sup.Input.isKeyDown(  "LEFT" ) || Sup.Input.isKeyDown( "A" ) ? 0.05 : 0;
    this.angle += Sup.Input.isKeyDown( "RIGHT" ) || Sup.Input.isKeyDown( "D" ) ? 0.05 : 0;
    
    this.actor.setPosition( Math.cos( this.angle ) * this.radius, 5, Math.sin( this.angle ) * this.radius );
    this.actor.lookAt( new Sup.Math.Vector3() );
    
    // Block picking with rays
    this.ray.setFromCamera( this.actor.camera, Sup.Input.getMousePosition() );
    let hits = this.ray.intersectActors( Game.blocks );
    
    // Make sure the actor is a block, because there's a skybox in there
    // I added it because the ray lags out if it's pointing at nothing
    if ( hits[ 0 ].actor.getName() === "Block"  ) {
      
      if ( this.selection ) { this.selection.modelRenderer.setColor( new Sup.Color( 0xffffff ) ); }
      this.selection = hits[ 0 ].actor
      
      // Block breaking
      if ( Sup.Input.wasMouseButtonJustPressed( 0 ) ) {
        
        if ( this.selection === Game.diamond ) { Sup.Audio.playSound( "Sounds/Yay" ); }
        else { Sup.Audio.playSound( "Sounds/Pop" ); }
        
        Game.blocks.splice( Game.blocks.indexOf( this.selection ), 1 ); // Remove actor from array
        this.selection.destroy();
        this.selection = null; // Remove actor from selection
      
      } else { this.selection.modelRenderer.setColor( new Sup.Color( 0xb0d8ff ) ); }
    
    }
    
  }
  
}
Sup.registerBehavior(CameraBehavior);